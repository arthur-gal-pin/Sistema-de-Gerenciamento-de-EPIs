import { Response, Request } from "express";
import { Empresa } from "../../models/amostras/Empresa";
import { EmpresaRepository } from "../../repositories/amostras/empresa.repository";

export const EmpresaController = {
    getAll: async (req: Request, res: Response): Promise<void> => {
        try {
            const result = await EmpresaRepository.findAll();

            if (!result || result.length === 0) {
                res.status(404).json({ message: 'Não foi encontrada nenhuma empresa no banco de dados.' });
                return; 
            }
            
            res.status(200).json({ message: 'Empresas encontradas:', data: result });
        } catch (error: any) {
            res.status(400).json({ message: error.message });
        }
    },

    getId: async (req: Request, res: Response): Promise<void> => {
        try {
            const { id } = req.params;

            if (!id ||typeof id !== 'string' || id.length !== 36) { 
                res.status(400).json({ message: 'Não foi possível processar a requisição - ID inválido inserido.' });
                return; 
            }

            const result = await EmpresaRepository.findById(id);

            if (!result) {
                res.status(404).json({ message: 'Não foi encontrada nenhuma empresa com esse ID.' });
                return; 
            }

            res.status(200).json({ message: 'Requisição bem-sucedida:', data: result });
        } catch (error: any) {
            res.status(500).json({ message: error.message });
        }
    },

    getNome: async (req: Request, res: Response): Promise<void> => {
        try {
            const {nome} = req.params;
            
            if (!nome || nome.length < 3 || typeof nome !== 'string') {
                res.status(400).json({ message: 'Não foi possível processar a requisição - O nome deve ter ao menos 3 caracteres.' });
                return; 
            }

            const result = await EmpresaRepository.findByName(nome);

            if (!result || result.length === 0) {
                res.status(404).json({ message: 'Não foi encontrada nenhuma empresa com esse nome.' });
                return; 
            }

            res.status(200).json({ message: 'Requisição bem-sucedida:', data: result });
        } catch (error: any) {
            res.status(400).json({ message: error.message });
        }
    },

    create: async (req: Request, res: Response): Promise<void> => {
        try {
            const {nomeEmpresa} = req.body;
            if(!nomeEmpresa ||  typeof nomeEmpresa !== 'string') {
                res.status(400).json({message: "É necessário que você coloque um nome para o registro de empresa."});
                return;
            }
            
            const domainEmpresa = Empresa.create({ nomeEmpresa });
            
            const result = await EmpresaRepository.create(domainEmpresa.toJSON());
            
            res.status(201).json({ message: 'Requisição bem sucedida:', data: result });
        } catch (error: any) {
            res.status(400).json({ message: error.message });
        }
    },

    update: async (req: Request, res: Response): Promise<void> => {
        try {
            const id = req.params.id;
            const nomeNovo = req.body.nomeEmpresa;

            if(!id || !nomeNovo || typeof id !== 'string' || typeof nomeNovo !== 'string'){
                res.status(400).json({message: 'Dados inválidos foram inseridos.'});
                return;
            }

            const empresaAtual = await EmpresaRepository.findById(id);
            if (!empresaAtual) {
                res.status(404).json({ message: 'Não foi encontrada nenhuma empresa com esse ID.' });
                return; 
            }

            const domainEmpresa = Empresa.edit(id, { nomeEmpresa: nomeNovo });

            const result = await EmpresaRepository.update(id, domainEmpresa.toJSON());

            res.status(200).json({ message: 'Empresa atualizada com sucesso.', data: result });
        } catch (error: any) {
            res.status(400).json({ message: error.message });
        }
    },

    delete: async (req: Request, res: Response): Promise<void> => {
        try {
            const id = req.params.id;

            if (!id || id.length !== 36 || typeof id!=='string') { 
                res.status(400).json({ message: 'O id inserido é inválido.' });
                return;
            }

            const result = await EmpresaRepository.delete(id);

            if (!result) {
                res.status(400).json({ message: 'Não foi possível apagar. Nenhuma Empresa encontrada com esse ID.' });
                return;
            }

            res.status(200).json({ message: 'Requisição bem-sucedida. Empresa removida.' });
        } catch (error: any) {
            res.status(400).json({ message: error.message });
        }
    }
};